# E-commerce Catalog Service

A production-oriented Product Catalog module for an e-commerce application.

## Stack

- Java 21
- Spring Boot 3.5.x
- Spring Web
- Spring Data JPA / Hibernate
- PostgreSQL 17
- Flyway
- SpringDoc OpenAPI / Swagger UI
- JUnit 5 + MockMvc + Testcontainers
- Docker / Docker Compose (or Colima)

## Features

- Recursive category hierarchy
- Category CRUD and hierarchy validation
- Product CRUD
- Product variants / global SKU model
- Positive price validation
- Controlled currency enum
- Database-level SKU uniqueness
- Search and category filtering
- Explicit Swagger-friendly pagination and sorting
- Consistent validation/error responses
- Local image upload, download, and deletion
- Product-level or variant-level image association
- Flyway migrations
- Integration tests using PostgreSQL/Testcontainers

## Run locally on macOS

The application expects PostgreSQL on localhost:5432.

Start PostgreSQL (Docker/Colima):

```bash
docker-compose up -d postgres
```

If your Maven settings point to an Oracle internal Artifactory that is unavailable outside the corporate network, use the provided clean settings file:

```bash
mvn -s /tmp/maven-clean-settings.xml -gs /tmp/maven-clean-settings.xml test
```

Run the application:

```bash
mvn -s /tmp/maven-clean-settings.xml -gs /tmp/maven-clean-settings.xml spring-boot:run
```

Application:

- API: http://localhost:8080
- Health: http://localhost:8080/actuator/health
- Swagger UI: http://localhost:8080/swagger-ui.html
- OpenAPI JSON: http://localhost:8080/v3/api-docs

## Default database

- Database: `ecommerce`
- Username: `ecommerce`
- Password: `ecommerce`
- Port: `5432`

Override with environment variables:

```text
DB_URL
DB_USERNAME
DB_PASSWORD
PORT
IMAGE_STORAGE_DIR
IMAGE_MAX_SIZE_BYTES
```

## Core APIs

### Categories

```text
POST   /api/v1/categories
GET    /api/v1/categories/{id}
GET    /api/v1/categories?parentId={id}
PUT    /api/v1/categories/{id}
DELETE /api/v1/categories/{id}
```

### Products

```text
POST   /api/v1/products
GET    /api/v1/products/{id}
GET    /api/v1/products
PUT    /api/v1/products/{id}
DELETE /api/v1/products/{id}
```

List example:

```text
GET /api/v1/products?page=0&size=20&sort=name,asc
```

Filter by category:

```text
GET /api/v1/products?categoryId=<uuid>&page=0&size=20&sort=name,asc
```

Search by product name:

```text
GET /api/v1/products?search=iphone&page=0&size=20&sort=name,asc
```

Allowed sort properties:

- `name`
- `brand`
- `slug`
- `createdAt`
- `updatedAt`

### Product images

```text
POST   /api/v1/products/{productId}/images
GET    /api/v1/products/{productId}/images/{imageId}/file
DELETE /api/v1/products/{productId}/images/{imageId}
```

Supported uploads:

- JPEG
- PNG
- WEBP

Maximum file size: 5 MB.

Files are stored under `./uploads` by default. PostgreSQL stores image metadata, not binary image content.

## Validation

Examples of invalid data that are rejected:

- blank product name
- blank SKU
- invalid SKU format
- zero or negative price
- unsupported currency
- nonexistent category
- duplicate SKU
- invalid category parent relationship
- category hierarchy cycle
- category deletion with children/products
- unsupported image type
- image larger than configured size

Duplicate SKU returns HTTP 409 Conflict.

## Database migrations

Flyway migrations live in:

```text
src/main/resources/db/migration
```

`V1__init_catalog.sql` creates the initial catalog schema.

`V2__catalog_hardening_and_images.sql` adds validation constraints, category indexes, and image metadata/storage support.

## Tests

Integration tests use Testcontainers and PostgreSQL. Docker must be available when running them.

```bash
mvn -s /tmp/maven-clean-settings.xml -gs /tmp/maven-clean-settings.xml test
```

## Next module

The intended next domain module is Inventory Management. Inventory should reference the sellable `ProductVariant` by SKU and maintain quantities such as:

```text
onHand
reserved
available
```
