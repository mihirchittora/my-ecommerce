package com.shop.catalog.image;

import com.shop.catalog.common.BadRequestException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

@Service
public class LocalImageStorageService implements ImageStorageService {
    private static final Set<String> ALLOWED_TYPES = Set.of("image/jpeg", "image/png", "image/webp");

    private final Path root;
    private final long maxBytes;

    public LocalImageStorageService(
            @Value("${app.images.storage-dir:./uploads}") String storageDir,
            @Value("${app.images.max-size-bytes:5242880}") long maxBytes) {
        this.root = Path.of(storageDir).toAbsolutePath().normalize();
        this.maxBytes = maxBytes;
        try {
            Files.createDirectories(root);
        } catch (IOException ex) {
            throw new IllegalStateException("Unable to initialize image storage: " + root, ex);
        }
    }

    @Override
    public StoredImage store(MultipartFile file, String productDirectory) {
        if (file == null || file.isEmpty()) {
            throw new BadRequestException("Image file is required");
        }
        if (file.getSize() > maxBytes) {
            throw new BadRequestException("Image exceeds maximum size of " + maxBytes + " bytes");
        }
        String contentType = file.getContentType();
        if (contentType == null || !ALLOWED_TYPES.contains(contentType.toLowerCase(Locale.ROOT))) {
            throw new BadRequestException("Unsupported image type. Allowed types: JPEG, PNG, WEBP");
        }

        String extension = switch (contentType.toLowerCase(Locale.ROOT)) {
            case "image/jpeg" -> ".jpg";
            case "image/png" -> ".png";
            case "image/webp" -> ".webp";
            default -> throw new BadRequestException("Unsupported image type");
        };

        String safeProductDirectory = productDirectory.replaceAll("[^A-Za-z0-9_-]", "");
        if (safeProductDirectory.isBlank()) {
            throw new BadRequestException("Invalid product directory");
        }

        String filename = UUID.randomUUID() + extension;
        Path directory = root.resolve("products").resolve(safeProductDirectory).normalize();
        if (!directory.startsWith(root)) {
            throw new BadRequestException("Invalid image path");
        }
        Path target = directory.resolve(filename).normalize();
        if (!target.startsWith(root)) {
            throw new BadRequestException("Invalid image path");
        }

        try {
            Files.createDirectories(directory);
            Files.copy(file.getInputStream(), target, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException ex) {
            throw new IllegalStateException("Unable to store image", ex);
        }

        String storageKey = root.relativize(target).toString().replace(java.io.File.separatorChar, '/');
        String originalFilename = StringUtils.cleanPath(
                file.getOriginalFilename() == null ? "image" : file.getOriginalFilename());
        return new StoredImage(storageKey, originalFilename, contentType, file.getSize());
    }

    @Override
    public void delete(String storageKey) {
        if (storageKey == null || storageKey.isBlank()) {
            return;
        }
        try {
            Path target = resolve(storageKey);
            Files.deleteIfExists(target);
        } catch (IOException ex) {
            throw new IllegalStateException("Unable to delete stored image", ex);
        }
    }

    @Override
    public Path resolve(String storageKey) {
        Path target = root.resolve(storageKey).normalize();
        if (!target.startsWith(root)) {
            throw new BadRequestException("Invalid image storage key");
        }
        return target;
    }
}
